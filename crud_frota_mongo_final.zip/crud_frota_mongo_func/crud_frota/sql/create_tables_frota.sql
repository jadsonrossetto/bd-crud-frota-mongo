ALTER TABLE veiculos DROP CONSTRAINT cnpj;
ALTER TABLE motoristas DROP CONSTRAINT codVeiculo;

DROP TABLE filiais;
DROP TABLE veiculos;
DROP TABLE motoristas;

DROP SEQUENCE VEICULO_CODVEICULO_SEQ;
DROP SEQUENCE MOTORISTA_CODMOTORISTA_SEQ;



CREATE TABLE filiais (
                cnpj VARCHAR2(14) NOT NULL,
                regiao VARCHAR2(150) NOT NULL,
                CONSTRAINT FILIAIS_FK PRIMARY KEY (cnpj)
);


CREATE TABLE veiculos (
                codigo_veiculo NUMBER NOT NULL,
                placa VARCHAR2(7) NOT NULL,
                cnpj VARCHAR2(14) NOT NULL,
                CONSTRAINT VEICULOS_PK PRIMARY KEY (codVeiculo)
);


CREATE TABLE motoristas (
                codigo_motorista NUMBER NOT NULL,
                cpf VARCHAR2(11) NOT NULL,
                nome VARCHAR2(100) NOT NULL,
                codigo_veiculo NUMBER NOT NULL,
                CONSTRAINT MOTORISTAS_PK PRIMARY KEY (codMotorista)
);

CREATE SEQUENCE VEICULO_CODVEICULO_SEQ;
CREATE SEQUENCE MOTORISTA_CODMOTORISTA_SEQ;

ALTER TABLE veiculos ADD CONSTRAINT FILIAIS_VEICULOS_FK
FOREIGN KEY (cnpj)
REFERENCES filiais (cnpj)
NOT DEFERRABLE;

ALTER TABLE motoristas ADD CONSTRAINT VEICULOS_MOTORISTAS_FK
FOREIGN KEY (codigo_veiculo)
REFERENCES veiculos (codigo_veiculo)
NOT DEFERRABLE;
 