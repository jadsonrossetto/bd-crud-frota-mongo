import pandas as pd
from bson import ObjectId
from reports.relatorios import Relatorio

from model.motoristas import Motorista
from model.veiculos import Veiculo

from controller.controller_veiculos import Controller_Veiculos

from conexion.mongo_queries import MongoQueries



class Controller_Motoristas:
    def __init__(self):
        self.ctrl_veiculos = Controller_Veiculos()
        self.mongo = MongoQueries()
        self.relatorio = Relatorio()
        
    def inserir_motorista(self) -> Motorista:
        opcao_continuar = 's'
        while(opcao_continuar.lower() == 's'):
            # Cria uma nova conexão com o banco
            self.mongo.connect()
            
            # Lista as Veiculos existentes para inserir no Motorista
            self.relatorio.get_relatorio_veiculos()
            codigo_veiculo = int(input("Digite o número do codigo do Veiculo: "))
            veiculo = self.valida_veiculo(codigo_veiculo)
            if veiculo == None:
                return None

            # Solicita o codigo do motorista que irá cadastrar
            codigo_motorista = int(input(f"Informe o codigo do motorista: "))
            # Solicita o cpf que será cadastrado no motorista
            cpf = str(input("Digite o CPF do motorista: "))
            # Solicita o nome que será cadastrado no motorista
            nome = str(input("Digite o nome do motorista: "))

            # Cria um dicionário para mapear as variáveis de entrada e saída
            data = dict(codigo_motorista=codigo_motorista, cpf=cpf, nome=nome, codigo_veiculo=int(veiculo.get_codigo_veiculo()))
            # Insere e recupera o codigo do motorista
            id_motorista = self.mongo.db["motoristas"].insert_one(data)
            # Recupera os dados do novo motorista criado transformando em um DataFrame
            df_motorista = self.recupera_motorista(id_motorista.inserted_id)
            # Cria um novo objeto Motorista
            novo_motorista = Motorista(df_motorista.codigo_motorista.values[0], df_motorista.cpf.values[0], df_motorista.nome.values[0], veiculo)
            # Exibe os atributos do novo motorista
            print(novo_motorista.to_string())
            print()
            opcao_continuar = input("Quer continuar inserindo motoristas? [S ou N]: ")
            # Retorna o objeto novo_motorista para utilização posterior, caso necessário

        return novo_motorista
        

    def atualizar_motorista(self) -> Motorista:
        opcao_continuar = 's'
        while(opcao_continuar.lower() == 's'):
            # Cria uma nova conexão com o banco que permite alteração
            self.mongo.connect()

            # Solicita ao usuário o código do motorista a ser alterado
            codigo_motorista = int(input("Código do Motorista que irá alterar: "))

            # Verifica se o motorista existe na base de dados
            if not self.verifica_existencia_motorista(codigo_motorista):

                # Lista as veiculos existentes para inserir no motorista
                self.relatorio.get_relatorio_veiculos()
                codigo_veiculo = int(input("Digite o número do codigo do veiculos: "))
                veiculo = self.valida_veiculo(codigo_veiculo)
                if veiculo == None:
                    return None

                # Solicita o cpf que será cadastrado no motorista
                cpf = str(input("Digite o CPF do motorista (Novo): "))
                # Solicita o nome que será cadastrado no motorista
                nome = str(input("Digite o nome do motorista (Novo): "))

                # Atualiza a veiculo do motorista existente
                self.mongo.db["motoristas"].update_one({"codigo_motorista": codigo_motorista},
                                                    {"$set": {"cpf": f'{cpf}',
                                                            "nome": f'{nome}',
                                                            "codigo_veiculo": f'{veiculo.get_codigo_veiculo()}'
                                                            }
                                                    })
                # Recupera os dados do novo motorista criado transformando em um DataFrame
                df_motorista = self.recupera_motorista_codigo(codigo_motorista)
                # Cria um novo objeto Motorista
                motorista_atualizado = Motorista(df_motorista.codigo_motorista.values[0], df_motorista.cpf.values[0], df_motorista.nome.values[0], veiculo)
                # Exibe os atributos do novo veiculo
                print(motorista_atualizado.to_string())
                # Retorna o objeto veiculo_atualizado para utilização posterior, caso necessário
                return motorista_atualizado
            else:
                self.mongo.close()
                print(f"O código {codigo_motorista} não existe.")
                opcao_continuar = input("Quer continuar atualizando motoristas? [S ou N]: ")
        return None

    def excluir_motorista(self):
        opcao_continuar = 's'
        while(opcao_continuar.lower() == 's'):
                # Cria uma nova conexão com o banco que permite alteração
            self.mongo.connect()

            # Solicita ao usuário o código do produto a ser alterado
            codigo_motorista = int(input("Código do Motorista que irá excluir: "))

            # Verifica se o motorista existe na base de dados
            if not self.verifica_existencia_motorista(codigo_motorista):
                # Recupera os dados do novo motorista criado transformando em um DataFrame
                df_motorista = self.recupera_motorista_codigo(codigo_motorista)
                veiculo = self.valida_veiculo(df_motorista.codigo_veiculo.values[0])
                
            opcao_excluir = input(f"Tem certeza que deseja excluir o motorista {codigo_motorista} [S ou N]: ")
            if opcao_excluir.lower() == "s":
                # Remove o motorista da tabela
                self.mongo.db["motoristas"].delete_one({"codigo_motorista": codigo_motorista})
                # Cria um novo objeto Motorista para informar que foi removido
                motorista_excluido = Motorista(df_motorista.codigo_motorista.values[0], df_motorista.cpf.values[0], df_motorista.nome.values[0], veiculo)
                self.mongo.close()
                # Exibe os atributos do veiculo excluído
                print("Motorista Removido com Sucesso!")
                print(motorista_excluido.to_string())
            else:
                self.mongo.close()
                print(f"O código {codigo_motorista} não existe.")
            opcao_continuar = input("Quer continuar excluindo motoristas? [S ou N]: ")

    def verifica_existencia_motorista(self, codigo:int=None, external: bool = False) -> bool:
        # Recupera os dados do novo motorista criado transformando em um DataFrame
        df_motorista = self.recupera_motorista_codigo(codigo=codigo, external=external)
        return df_motorista.empty

    def recupera_motorista(self, _id:ObjectId=None) -> bool:
        # Recupera os dados do novo pedido criado transformado em um DataFrame
        df_motorista = pd.DataFrame(list(self.mongo.db["motoristas"].find({"_id":_id}, {"codigo_motorista": 1,
                                                                                     "cpf": 1, "nome": 1,
                                                                                     "veiculo" : 1, "_id": 0})
                                                                                     ))
        return df_motorista

    def recupera_motorista_codigo(self, codigo: int = None, external: bool = False) -> bool:
        if external:
            # Cria uma nova conexão com o banco que permite alteração
            self.mongo.connect()

        # Recupera os dados do novo pedido criado transformando em um DataFrame
        df_motorista = pd.DataFrame(list(self.mongo.db["motoristas"].find({"codigo_motorista": codigo},
                                                                    {"codigo_motorista": 1, "cpf": 1, "nome": 1, "codigo_veiculo": 1,
                                                                     "_id": 0})))

        if external:
            # Fecha a conexão com o Mongo
            self.mongo.close()

        return df_motorista

    def valida_veiculo(self, codigo_veiculo:int=None) -> Veiculo:
        if self.ctrl_veiculos.verifica_existencia_veiculo(codigo_veiculo, True):
            print(f"O Veiculo {codigo_veiculo} informado não existe na base.")
            return None
        else:
            # Recupera os dados da nova veiculo criado transformando em um DataFrame
            df_veiculo = self.ctrl_veiculos.recupera_veiculo_codigo(codigo_veiculo, external=True)
            # Valida a filial
            filial = self.ctrl_veiculos.valida_filial(df_veiculo.cnpj.values[0])
            # Cria um novo objeto veiculo
            veiculo = Veiculo(df_veiculo.codigo_veiculo.values[0], df_veiculo.placa.values[0], filial)
            return veiculo