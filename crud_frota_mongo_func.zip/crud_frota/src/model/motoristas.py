from model.veiculos import Veiculo


class Motorista:
    def __init__(self, 
                 codigo_motorista:int=None,
                 cpf:str=None,
                 nome:str= None,
                 veiculo:Veiculo=None
                 ):
        self.set_codigo_motorista(codigo_motorista)
        self.set_cpf(cpf)
        self.set_nome(nome)
        self.set_veiculo(veiculo)


    def set_codigo_motorista(self, codigo_motorista:int):
        self.codigo_motorista = codigo_motorista

    def set_cpf(self, cpf:str):
        self.cpf = cpf

    def set_nome(self, nome:str):
        self.nome = nome

    def set_veiculo(self, veiculo:Veiculo):
        self.veiculo = veiculo

    def get_codigo_motorista(self) -> int:
        return self.codigo_motorista

    def get_cpf(self) -> str:
        return self.cpf

    def get_nome(self) -> str:
        return self.nome

    def get_veiculo(self) -> Veiculo:
        return self.veiculo
    
    def get_codigo_veiculo(self) -> int:
        return self.veiculo.codigo_veiculo

    def to_string(self) -> str:
        return f"codigo_motorista: {self.get_codigo_motorista()} | CPF: {self.get_cpf()} | Nome: {self.get_nome()}" \
               f"| codigo_veiculo: {self.get_codigo_veiculo()}"