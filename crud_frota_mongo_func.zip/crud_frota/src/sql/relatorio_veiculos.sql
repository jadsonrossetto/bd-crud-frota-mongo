select v.codVeiculo
       , v.placa
       , v.cnpj
  from veiculos v
 order by v.coselect v.codVeiculo
       , v.placa
       , v.cnpj
  from veiculos v
 order by v.codVeiculo