import pandas as pd
from reports.relatorios import Relatorio as relatorios
from utils import config
from model.filiais import Filial
from conexion.mongo_queries import MongoQueries
from controller.controller_veiculos import Controller_Veiculos

class Controller_Filiais:
    def __init__(self):
        self.mongo = MongoQueries()
        
    def inserir_filial(self) -> Filial:
        opcao_continuar = 's'
        while(opcao_continuar.lower() == 's'):   
            # Cria uma nova conexão com o banco que permite alteração
            self.mongo.connect()

                # Solicita ao usuario o novo CNPJ
            cnpj = input("CNPJ: ")

            if self.verifica_existencia_filial(cnpj)== False:
                self.mongo.close()
                print(f"O CNPJ {cnpj} já está cadastrado.")
                return None
            else:
                # Solicita ao usuario a nova regiao
                regiao = input("Regiao: ")
                # Insere e persiste a nova filial
                self.mongo.db["filiais"].insert_one({"cnpj": cnpj, "regiao": regiao})
                # Recupera os dados da nova filial criado transformando em um DataFrame
                df_filial = self.recupera_filial(cnpj)
                # Cria um novo objeto Filial
                nova_filial = Filial(df_filial.cnpj.values[0], df_filial.regiao.values[0])
                # Exibe os atributos da nova filial
                print(nova_filial.to_string())
                self.mongo.close()
                opcao_continuar = input("Quer continuar inserindo filiais? [S ou N]: ")
                if (opcao_continuar.lower() == 's'):
                    config.clear_console()
                
        # Retorna o objeto nova_filial para utilização posterior, caso necessário
        return nova_filial        
            

    def atualizar_filial(self) -> Filial:
        opcao_continuar = 's'
        while(opcao_continuar.lower() == 's'):   
            # Cria uma nova conexão com o banco que permite alteração
            self.mongo.connect()

            # Solicita ao usuário o código do cliente a ser alterado
            cnpj = int(input("CNPJ da filial que deseja alterar a regiao: "))

            # Verifica se o cliente existe na base de dados
            if self.verifica_existencia_filial(cnpj):
                self.mongo.close()
                print(f"O CNPJ {cnpj} não existe.")
                return None
            else:
                # Solicita a nova regiao da filial
                nova_regiao = input("Regiao (Novo): ")
                # Atualiza a regiao da filial existente
                self.mongo.db["filiais"].update_one({"cnpj": f"{cnpj}"}, {"$set": {"regiao": nova_regiao}})
                # Recupera os dados do novo cliente criado transformando em um DataFrame
                df_filial = self.recupera_filial(cnpj)
                # Cria um novo objeto filial
                filial_atualizado = Filial(df_filial.cnpj.values[0], df_filial.regiao.values[0])
                # Exibe os atributos da nova Filial
                print(filial_atualizado.to_string())
                self.mongo.close()
                opcao_continuar = input("Quer continuar atualizando filiais? [S ou N]: ")
                if (opcao_continuar.lower() == 's'):
                    config.clear_console()
            
        # Retorna o objeto filial_atualizado para utilização posterior, caso necessário 
        return filial_atualizado
                

    def excluir_filial(self):
        opcao_continuar = 's'
        while(opcao_continuar.lower() == 's'):  
            # Cria uma nova conexão com o banco que permite alteração
            self.mongo.connect()

            # Solicita ao usuário o CPF do Cliente a ser alterado
            cnpj = int(input("CNPJ da Filial que irá excluir: "))

            opcao_excluir = input(f"Tem certeza que deseja excluir a filial {cnpj}? Todos os veiculos vinculados a ela também serão excluidos! [S ou N]: ")
            if opcao_excluir.lower() == "s":
                # Verifica se a filial existe na base de dados
                if self.verifica_existencia_filial(cnpj):
                    self.mongo.close()
                    print(f"O CNPJ {cnpj} não existe.")
                else:
                    # Recupera os dados da nova filial criado transformando em um DataFrame
                    df_filial = self.recupera_filial(cnpj)
                    # Remove o filial da tabela
                    self.mongo.db["filiais"].delete_one({"cnpj":f"{cnpj}"})
                    # Remove o veiculo da tabela
                    Controller_Veiculos.remove_veiculo(cnpj)
                    # Cria um novo objeto Filial para informar que foi removido
                    filial_excluido = Filial(df_filial.cnpj.values[0], df_filial.regiao.values[0])
                    self.mongo.close()
                    # Exibe os atributos do filial excluído
                    print("Filial Removido com Sucesso!")
                    print(filial_excluido.to_string())
                    opcao_continuar = input("Quer continuar removendo filiais? [S ou N]: ")
                    if (opcao_continuar.lower() == 's'):
                        config.clear_console()
                

    def verifica_existencia_filial(self, cnpj:str=None, external:bool=False) -> bool:
        if external:
            #Cria uma nova conexão com o banco que permite alteração
            self.mongo.connect()

        # Recupera os dados do novo filial criado transformando em um DataFrame
        df_filial = pd.DataFrame(self.mongo.db["filiais"].find({"cnpj":f"{cnpj}"}, {"cnpj": 1, "regiao": 1, "_id": 0}))

        if external:
            # Fecha a conexão com o Mongo
            self.mongo.close()

        return df_filial.empty

    def recupera_filial(self, cnpj:str=None, external:bool=False) -> pd.DataFrame:
        if external:
            # Cria uma nova conexão com o banco que permite alteração
            self.mongo.connect()

        # Recupera os dados da nova filial criada transformando em um DataFrame
        df_filial = pd.DataFrame(list(self.mongo.db["filiais"].find({"cnpj": f"{cnpj}"}, {"cnpj": 1, "regiao": 1, "_id": 0})))

        if external:
            # Fecha a conexão com o Mongo
            self.mongo.close()

        return df_filial
