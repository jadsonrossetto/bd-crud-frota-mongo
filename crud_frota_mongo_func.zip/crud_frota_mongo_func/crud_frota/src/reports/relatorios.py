from conexion.mongo_queries import MongoQueries
import pandas as pd
from pymongo import ASCENDING, DESCENDING

class Relatorio:
    def __init__(self):
        pass

    def get_relatorio_filiais(self):
        # Cria uma nova conexão com o banco que permite alteração
        mongo = MongoQueries()
        mongo.connect()
        # Recupera os dados transformando em um DataFrame
        query_result = mongo.db["filiais"].find({},
                                                 {"cnpj": 1,
                                                  "regiao": 1,
                                                  "_id": 0
                                                  }).sort("regiao", ASCENDING)
        df_filiais = pd.DataFrame(list(query_result))
        # Fecha a conexão com o Mongo
        mongo.close()
        # Exibe o resultado
        print(df_filiais)
        input("Pressione Enter para Sair do Relatório de Filiais")

    def get_relatorio_veiculos(self):
        # Cria uma nova conexão com o banco que permite alteração
        mongo = MongoQueries()
        mongo.connect()
        # Recupera os dados transformando em um DataFrame
        query_result = mongo.db["veiculos"].find({},
                                                {"codigo_veiculo": 1,
                                                 "placa": 1,
                                                 "cnpj": 1,
                                                 "_id": 0
                                                 }).sort("codigo_veiculo", ASCENDING)
        df_veiculo = pd.DataFrame(list(query_result))
        # Fecha a conexão com o Mongo
        mongo.close()
        # Exibe o resultado
        print(df_veiculo)
        input("Pressione Enter para Sair do Relatório de Veiculos")

    def get_relatorio_motoristas(self):
        # Cria uma nova conexão com o banco que permite alteração
        mongo = MongoQueries()
        mongo.connect()
        # Recupera os dados transformando em um DataFrame
        query_result = mongo.db["motoristas"].find({},
                                                {"codigo_motorista": 1,
                                                 "codigo_veiculo": 1,
                                                 "cpf": 1,
                                                 "nome": 1,
                                                 "_id": 0
                                                 }).sort("codigo_motorista", ASCENDING)
        df_motorista = pd.DataFrame(list(query_result))
        # Fecha a conexão com o Mongo
        mongo.close()
        # Exibe o resultado
        print(df_motorista)
        input("Pressione Enter para Sair do Relatório de Motoristas")