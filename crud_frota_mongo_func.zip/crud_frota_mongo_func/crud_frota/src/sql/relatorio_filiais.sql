select f.cnpj
     , f.regiao
  from filiais f
 order by f.cnpj