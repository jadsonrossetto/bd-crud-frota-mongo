select f.cnpj
     , f.regiao
  from filiais f
 order by f.cnpjselect m.codMotorista
      ,m.cpf
      , m.nome
  from motoristas m
 order by m.cpf