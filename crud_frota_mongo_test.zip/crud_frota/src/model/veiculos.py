from model.filiais import Filial


class Veiculo:
    def __init__(self, 
                 codigo_veiculo:int=None,
                 placa:str=None,
                 filial:Filial=None
                 ):
        self.set_codigo_veiculo(codigo_veiculo)
        self.set_placa(placa)
        self.set_filial(filial)


    def set_codigo_veiculo(self, codigo_veiculo:int):
        self.codigo_veiculo = codigo_veiculo

    def set_placa(self, placa:str):
        self.placa = placa

    def set_filial(self, filial:Filial):
        self.filial = filial

    def get_codigo_veiculo(self) -> int:
        return self.codigo_veiculo

    def get_placa(self) -> str:
        return self.placa

    def get_filial(self) -> Filial:
        return self.filial

    def to_string(self):
        return f"CodVeiculo: {self.get_codigo_veiculo()} | Placa: {self.get_placa()} | CNPJ: {self.get_filial().get_cnpj()}"
