
from model.filiais import Filial
from conexion.oracle_queries import OracleQueries

class Controller_Filiais:
    def __init__(self):
        pass
        
    def inserir_filial(self) -> Filial:
        from src.model.filiais import Filial
        from src.conexion.oracle_queries import OracleQueries

class Controller_Filiais:
    def __init__(self):
        pass
        
    def inserir_filial(self) -> Filial:
        ''' Ref.: https://cx-oracle.readthedocs.io/en/latest/user_guide/plsql_execution.html#anonymous-pl-sql-blocks'''
        
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        # Solicita ao usuario o novo CNPJ
        cnpj = input("CNPJ (Novo): ")

        if self.verifica_existencia_filial(oracle, cnpj):
            # Solicita ao usuario a nova regiao
            regiao = input("Regiao (Novo): ")
            # Insere e persiste a nova filial
            oracle.write(f"insert into filiais values ('{cnpj}', '{regiao}')")
            # Recupera os dados da nova filial criado transformando em um DataFrame
            df_filial = oracle.sqlToDataFrame(f"select cnpj, regiao from filiais where cnpj = '{cnpj}'")
            # Cria um novo objeto Filial
            nova_filial = Filial(df_filial.cnpj.values[0], df_filial.regiao.values[0])
            # Exibe os atributos da nova filial
            print(nova_filial.to_string())
            # Retorna o objeto nova_filial para utilização posterior, caso necessário
            return nova_filial
        else:
            print(f"O CNPJ {cnpj} já está cadastrado.")
            return None

    def atualizar_filial(self) -> Filial:
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        # Solicita ao usuário o código do cliente a ser alterado
        cnpj = int(input("CNPJ da filial que deseja alterar a regiao: "))

        # Verifica se o cliente existe na base de dados
        if not self.verifica_existencia_filial(oracle, cnpj):
            # Solicita a nova descrição da filial
            nova_regiao = input("Regiao (Novo): ")
            # Atualiza a regiao da filial existente
            oracle.write(f"update filiais set regiao = '{nova_regiao}' where cnpj = {cnpj}")
            # Recupera os dados do novo cliente criado transformando em um DataFrame
            df_filial = oracle.sqlToDataFrame(f"select cnpj, regiao from filiais where cnpj = {cnpj}")
            # Cria um novo objeto filial
            filial_atualizado = Filial(df_filial.cnpj.values[0], df_filial.regiao.values[0])
            # Exibe os atributos da nova Filial
            print(filial_atualizado.to_string())
            # Retorna o objeto filial_atualizado para utilização posterior, caso necessário
            return filial_atualizado
        else:
            print(f"O CNPJ {cnpj} não existe.")
            return None

    def excluir_filial(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        # Solicita ao usuário o CPF do Cliente a ser alterado
        cnpj = int(input("CNPJ da Filial que irá excluir: "))

        # Verifica se a filial existe na base de dados
        if not self.verifica_existencia_filial(oracle, cnpj):
            # Recupera os dados da nova filial criado transformando em um DataFrame
            df_filial = oracle.sqlToDataFrame(f"select cnpj, regiao from filiais where cnpj = {cnpj}")
            # Revome o filial da tabela
            oracle.write(f"delete from filiais where cnpj = {cnpj}")
            # Cria um novo objeto Filial para informar que foi removido
            filial_excluido = Filial(df_filial.cnpj.values[0], df_filial.regiao.values[0])
            # Exibe os atributos do filial excluído
            print("Filial Removido com Sucesso!")
            print(filial_excluido.to_string())
        else:
            print(f"O CNPJ {cnpj} não existe.")

    def verifica_existencia_filial(self, oracle:OracleQueries, cnpj:str=None) -> bool:
        # Recupera os dados do novo filial criado transformando em um DataFrame
        df_filial = oracle.sqlToDataFrame(f"select cnpj, regiao from filiais where cnpj = {cnpj}")
        return df_filial.empty