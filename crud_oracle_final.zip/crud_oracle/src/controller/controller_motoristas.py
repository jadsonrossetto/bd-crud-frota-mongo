
from model.motoristas import Motorista
from model.veiculos import Veiculo
from controller.controller_veiculos import Controller_Veiculos
from conexion.oracle_queries import OracleQueries

class Controller_Motoristas:
    def __init__(self):
        self.ctrl_veiculos = Controller_Veiculos()
        
    def inserir_motorista(self) -> Motorista:
        ''' Ref.: https://cx-oracle.readthedocs.io/en/latest/user_guide/plsql_execution.html#anonymous-pl-sql-blocks'''
        
        # Cria uma nova conexão com o banco
        oracle = OracleQueries()
        
        # Lista as Veiculos existentes para inserir no Motorista
        self.listar_veiculos(oracle, need_connect=True)
        codVeiculo = int(input("Digite o número do codigo do Veiculo: "))
        veiculo = self.valida_veiculo(oracle, codVeiculo)
        if veiculo == None:
            return None

        # Solicita o cpf que será cadastrado no motorista
        cpf = str(input("Digite o CPF do motorista: "))
        # Solicita o nome que será cadastrado no motorista
        nome = str(input("Digite o nome do motorista: "))

        # Recupera o cursores para executar um bloco PL/SQL anônimo
        cursor = oracle.connect()
        # Cria a variável de saída com o tipo especificado
        output_value = cursor.var(int)

        # Cria um dicionário para mapear as variáveis de entrada e saída
        data = dict(codMotorista=output_value, cpf=cpf, nome=nome, codVeiculo=int(veiculo.get_codVeiculo()))
        # Executa o bloco PL/SQL anônimo para inserção do novo produto e recuperação da chave primária criada pela sequence
        cursor.execute("""
        begin
            :codMotorista := MOTORISTA_CODMOTORISTA_SEQ.NEXTVAL;
            insert into motoristas values(:codMotorista, :cpf, :nome, :codVeiculo);
        end;
        """, data)
        # Recupera o código do novo veiculo
        codigo_motorista = output_value.getvalue()
        # Persiste (confirma) as alterações
        oracle.conn.commit()
        # Recupera os dados do novo motorista criado transformando em um DataFrame
        df_motorista = oracle.sqlToDataFrame(f"select codMotorista, cpf, nome, codVeiculo from motoristas where codMotorista = {codigo_motorista}")
        # Cria um novo objeto Motorista
        novo_motorista = Motorista(df_motorista.codmotorista.values[0], df_motorista.cpf.values[0], df_motorista.nome.values[0], veiculo)
        # Exibe os atributos do novo motorista
        print(novo_motorista.to_string())
        # Retorna o objeto novo_motorista para utilização posterior, caso necessário
        return novo_motorista

    def atualizar_motorista(self) -> Motorista:
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        # Solicita ao usuário o código do motorista a ser alterado
        codigo_motorista = int(input("Código do Motorista que irá alterar: "))

        # Verifica se o motorista existe na base de dados
        if not self.verifica_existencia_motorista(oracle, codigo_motorista):

            # Lista as veiculos existentes para inserir no motorista
            self.listar_veiculos(oracle, need_connect=True)
            codVeiculo = str(input("Digite o número do codigo do veiculos: "))
            veiculo = self.valida_veiculo(oracle, codVeiculo)
            if veiculo == None:
                return None

             # Solicita o cpf que será cadastrado no motorista
            cpf = str(input("Digite o CPF do motorista: "))
            # Solicita o nome que será cadastrado no motorista
            nome = str(input("Digite o nome do motorista: "))

            # Atualiza a veiculo do motorista existente
            oracle.write(f"update motoristas set cpf = '{cpf}', nome = '{nome}', codVeiculo = '{veiculo.get_codVeiculo()}' where codMotorista = {codigo_motorista}")
            # Recupera os dados do novo motorista criado transformando em um DataFrame
            df_motorista = oracle.sqlToDataFrame(f"select codMotorista, cpf, nome, codVeiculo from motoristas where codMotorista = {codigo_motorista}")
            # Cria um novo objeto Motorista
            motorista_atualizado = Motorista(df_motorista.codmotorista.values[0], df_motorista.cpf.values[0], df_motorista.nome.values[0], veiculo)
            # Exibe os atributos do novo veiculo
            print(motorista_atualizado.to_string())
            # Retorna o objeto veiculo_atualizado para utilização posterior, caso necessário
            return motorista_atualizado
        else:
            print(f"O código {codigo_motorista} não existe.")
            return motorista_atualizado

    def excluir_motorista(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        # Solicita ao usuário o código do produto a ser alterado
        codigo_motorista = int(input("Código do Motorista que irá excluir: "))

        # Verifica se o motorista existe na base de dados
        if not self.verifica_existencia_motorista(oracle, codigo_motorista):
            # Recupera os dados do novo motorista criado transformando em um DataFrame
            df_motorista = oracle.sqlToDataFrame(f"select codMotorista, nome, cpf, codVeiculo from motoristas where codMotorista = {codigo_motorista}")
            veiculo = self.valida_veiculo(oracle, df_motorista.codveiculo.values[0])

            
        opcao_excluir = input(f"Tem certeza que deseja excluir o motorista {codigo_motorista} [S ou N]: ")
        if opcao_excluir.lower() == "s":
            oracle.write(f"delete from motoristas where codMotorista = {codigo_motorista}")
            # Cria um novo objeto Motorista para informar que foi removido
            motorista_excluido = Motorista(df_motorista.codmotorista.values[0], df_motorista.cpf.values[0], df_motorista.nome.values[0], veiculo)
            # Exibe os atributos do veiculo excluído
            print("Motorista Removido com Sucesso!")
            print(motorista_excluido.to_string())
        else:
            print(f"O código {codigo_motorista} não existe.")

    def verifica_existencia_motorista(self, oracle:OracleQueries, codigo:int=None) -> bool:
        # Recupera os dados do novo motorista criado transformando em um DataFrame
        df_motorista = oracle.sqlToDataFrame(f"select codMotorista, cpf, nome, codVeiculo from motoristas where codMotorista = {codigo}")
        return df_motorista.empty

    def listar_veiculos(self, oracle:OracleQueries, need_connect:bool=False):
        query = """
                select v.codVeiculo
                    , v.placa 
                from veiculos v
                order by v.codVeiculo
                """
        if need_connect:
            oracle.connect()
        print(oracle.sqlToDataFrame(query))


    def valida_veiculo(self, oracle:OracleQueries, codVeiculo:str=None) -> Veiculo:
        if self.ctrl_veiculos.verifica_existencia_veiculo(oracle, codVeiculo):
            print(f"O Veiculo {codVeiculo} informado não existe na base.")
            return None
        else:
            oracle.connect()
            # Recupera os dados da nova veiculo criado transformando em um DataFrame
            df_veiculo = oracle.sqlToDataFrame(f"select codVeiculo, placa, cnpj from veiculos where codVeiculo = {codVeiculo}")
            filial = self.ctrl_veiculos.valida_filial(oracle, df_veiculo.cnpj.values[0])
            # Cria um novo objeto veiculo
            veiculo = Veiculo(df_veiculo.codveiculo.values[0], df_veiculo.placa.values[0], filial)
            return veiculo