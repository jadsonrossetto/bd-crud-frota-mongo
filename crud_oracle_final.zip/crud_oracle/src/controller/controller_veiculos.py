
from model.filiais import Filial
from model.veiculos import Veiculo
from controller.controller_filiais import Controller_Filiais
from conexion.oracle_queries import OracleQueries

class Controller_Veiculos:
    def __init__(self):
        self.ctrl_filial = Controller_Filiais()
        
    def inserir_veiculo(self) -> Veiculo:
        ''' Ref.: https://cx-oracle.readthedocs.io/en/latest/user_guide/plsql_execution.html#anonymous-pl-sql-blocks'''
        
        # Cria uma nova conexão com o banco
        oracle = OracleQueries()
        
        # Lista as Filiais existentes para inserir no veiculo
        self.listar_filiais(oracle, need_connect=True)
        cnpj = str(input("Digite o número do CNPJ da Filial: "))
        filial = self.valida_filial(oracle, cnpj)
        if filial == None:
            return None

        # Solicita a placa do veiculo que queira cadastrar
        placa = str(input(f"Informe a placa do veiculo: "))
        
        # Recupera o cursores para executar um bloco PL/SQL anônimo
        cursor = oracle.connect()
        # Cria a variável de saída com o tipo especificado
        output_value = cursor.var(int)

        # Cria um dicionário para mapear as variáveis de entrada e saída
        data = dict(codVeiculo=output_value, placa=placa, cnpj=filial.get_cnpj())
        # Executa o bloco PL/SQL anônimo para inserção do novo produto e recuperação da chave primária criada pela sequence
        cursor.execute("""
        begin
            :codVeiculo := VEICULO_CODVEICULO_SEQ.NEXTVAL;
            insert into veiculos values(:codVeiculo, :placa, :cnpj);
        end;
        """, data)
        # Recupera o código do novo veiculo
        codVeiculo = output_value.getvalue()
        # Persiste (confirma) as alterações
        oracle.conn.commit()
        # Recupera os dados do novo veiculo criado transformando em um DataFrame
        df_veiculo = oracle.sqlToDataFrame(f"select codVeiculo, placa, cnpj from veiculos where codVeiculo = {codVeiculo}")
        # Cria um novo objeto Veiculo
        novo_veiculo = Veiculo(df_veiculo.codveiculo.values[0], df_veiculo.placa.values[0], filial)
        # Exibe os atributos do novo veiculo
        print(novo_veiculo.to_string())
        # Retorna o objeto novo_veiculo para utilização posterior, caso necessário
        return novo_veiculo

    def atualizar_veiculo(self) -> Veiculo:
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        # Solicita ao usuário o código do produto a ser alterado
        codigo_veiculo = int(input("Código do Veiculo que irá alterar: "))

        # Verifica se o veiculo existe na base de dados
        if not self.verifica_existencia_veiculo(oracle, codigo_veiculo):

            # Lista as filiais existentes para inserir no veiculo
            self.listar_filiais(oracle, need_connect=True)
            cnpj = str(input("Digite o número do CNPJ da Filial: "))
            filial = self.valida_filial(oracle, cnpj)
            if filial == None:
                return None
            
            #Solicita a placa do veiculo
            placa = str(input("Digite a placa do veiculo: "))

            # Atualiza a filial do veiculo existente
            oracle.write(f"update veiculos set placa = '{placa}', cnpj = '{filial.get_cnpj()}' where codVeiculo = {codigo_veiculo}")
            # Recupera os dados do novo veiculo criado transformando em um DataFrame
            df_veiculo = oracle.sqlToDataFrame(f"select codVeiculo, placa, cnpj from veiculos where codVeiculo = {codigo_veiculo}")
            # Cria um novo objeto Produto
            veiculo_atualizado = Veiculo(df_veiculo.codveiculo.values[0], df_veiculo.placa.values[0], filial)
            # Exibe os atributos do novo veiculo
            print(veiculo_atualizado.to_string())
            # Retorna o objeto veiculo_atualizado para utilização posterior, caso necessário
            return veiculo_atualizado
        else:
            print(f"O código {codigo_veiculo} não existe.")
            return None

    def excluir_veiculo(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries(can_write=True)
        oracle.connect()

        # Solicita ao usuário o código do produto a ser alterado
        codigo_veiculo = int(input("Código do Veiculo que irá excluir: "))

        # Verifica se o veiculo existe na base de dados
        if not self.verifica_existencia_veiculo(oracle, codigo_veiculo):
            # Recupera os dados do novo veiculo criado transformando em um DataFrame
            df_veiculo = oracle.sqlToDataFrame(f"select codVeiculo, placa, cnpj from veiculos where codVeiculo = {codigo_veiculo}")
            filial = self.valida_filial(oracle, df_veiculo.cnpj.values[0])

            
        opcao_excluir = input(f"Tem certeza que deseja excluir o veiculo {codigo_veiculo} [S ou N]: ")
        if opcao_excluir.lower() == "s":
            # Remove o veiculo da tabela
            oracle.write(f"delete from veiculos where codVeiculo = {codigo_veiculo}")
            # Cria um novo objeto Veiculo para informar que foi removido
            veiculo_excluido = Veiculo(df_veiculo.codveiculo.values[0], df_veiculo.placa.values[0], filial)
            # Exibe os atributos do veiculo excluído
            print("Veiculo Removido com Sucesso!")
            print(veiculo_excluido.to_string())
        else:
            print(f"O código {codigo_veiculo} não existe.")

    def verifica_existencia_veiculo(self, oracle:OracleQueries, codigo:int=None) -> bool:
        # Recupera os dados do novo pedido criado transformando em um DataFrame
        df_veiculo = oracle.sqlToDataFrame(f"select codVeiculo, placa, cnpj from veiculos where codVeiculo = {codigo}")
        return df_veiculo.empty

    def listar_filiais(self, oracle:OracleQueries, need_connect:bool=False):
        query = """
                select f.cnpj
                    , f.regiao 
                from filiais f
                order by f.cnpj
                """
        if need_connect:
            oracle.connect()
        print(oracle.sqlToDataFrame(query))


    def valida_filial(self, oracle:OracleQueries, cnpj:str=None) -> Filial:
        if self.ctrl_filial.verifica_existencia_filial(oracle, cnpj):
            print(f"O CNPJ {cnpj} informado não existe na base.")
            return None
        else:
            oracle.connect()
            # Recupera os dados da nova filial criado transformando em um DataFrame
            df_filial = oracle.sqlToDataFrame(f"select cnpj, regiao from filiais where cnpj = {cnpj}")
            # Cria um novo objeto filial
            filial = Filial(df_filial.cnpj.values[0], df_filial.regiao.values[0])
            return filial
