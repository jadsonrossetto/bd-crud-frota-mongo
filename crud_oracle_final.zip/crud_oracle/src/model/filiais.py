class Filial:
    def __init__(self,
                 cnpj:str=None,
                 regiao:str=None
                ):
        self.set_cnpj(cnpj)
        self.set_regiao(regiao)

    def set_cnpj(self, cnpj:str):
        self.cnpj = cnpj

    def set_regiao(self, regiao:str):
        self.regiao = regiao

    def get_cnpj(self) -> str:
        return self.cnpj

    def get_regiao(self) -> str:
        return self.regiao

    def to_string(self) -> str:
        return f" CNPJ: {self.get_cnpj()} | Regiao: {self.get_regiao()} " 