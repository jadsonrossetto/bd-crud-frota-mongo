
from model.veiculos import Veiculo


class Motorista:
    def __init__(self, 
                 codMotorista:int=None,
                 cpf:str=None,
                 nome:str= None,
                 veiculo:Veiculo=None
                 ):
        self.set_codMotorista(codMotorista)
        self.set_cpf(cpf)
        self.set_nome(nome)
        self.set_veiculo(veiculo)


    def set_codMotorista(self, codMotorista:int):
        self.codMotorista = codMotorista

    def set_cpf(self, cpf:str):
        self.cpf = cpf

    def set_nome(self, nome:str):
        self.nome = nome

    def set_veiculo(self, veiculo:Veiculo):
        self.veiculo = veiculo

    def get_codMotorista(self) -> int:
        return self.codMotorista

    def get_cpf(self) -> str:
        return self.cpf

    def get_nome(self) -> str:
        return self.nome

    def get_veiculo(self) -> Veiculo:
        return self.veiculo

    def get_codVeiculo(self) -> int:
        return self.veiculo.get_codVeiculo()

    def to_string(self) -> str:
        return f"codMotorista: {self.get_codMotorista()} | CPF: {self.get_cpf()} | Nome: {self.get_nome()}" \
               f"| codVeiculo: {self.get_codVeiculo()}"