
from model.filiais import Filial


class Veiculo:
    def __init__(self, 
                 codVeiculo:int=None,
                 placa:str=None,
                 filial:Filial=None
                 ):
        self.set_codVeiculo(codVeiculo)
        self.set_placa(placa)
        self.set_filial(filial)


    def set_codVeiculo(self, codVeiculo:int):
        self.codVeiculo = codVeiculo

    def set_placa(self, placa:str):
        self.placa = placa

    def set_filial(self, filial:Filial):
        self.filial = filial

    def get_codVeiculo(self) -> int:
        return self.codVeiculo

    def get_placa(self) -> str:
        return self.placa

    def get_filial(self) -> Filial:
        return self.filial

    def to_string(self):
        return f"CodVeiculo: {self.get_codVeiculo()} | Placa: {self.get_placa()} | CNPJ: {self.get_filial().get_cnpj()}" 
