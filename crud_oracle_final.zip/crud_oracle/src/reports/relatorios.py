from conexion.oracle_queries import OracleQueries

class Relatorio:
    def __init__(self):
        # Abre o arquivo com a consulta e associa a um atributo da classe
        with open("src/sql/relatorio_filiais.sql") as f:
            self.query_relatorio_filiais = f.read()

        # Abre o arquivo com a consulta e associa a um atributo da classe
        with open("src/sql/relatorio_veiculos.sql") as f:
            self.query_relatorio_veiculos = f.read()

        # Abre o arquivo com a consulta e associa a um atributo da classe
        with open("src/sql/relatorio_motoristas.sql") as f:
            self.query_relatorio_motoristas = f.read()

    def get_relatorio_filiais(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Recupera os dados transformando em um DataFrame
        print(oracle.sqlToDataFrame(self.query_relatorio_filiais))
        input("Pressione Enter para Sair do Relatório de Filiais")

    def get_relatorio_veiculos(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Recupera os dados transformando em um DataFrame
        print(oracle.sqlToDataFrame(self.query_relatorio_veiculos))
        input("Pressione Enter para Sair do Relatório de Veiculos")

    def get_relatorio_motoristas(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Recupera os dados transformando em um DataFrame
        print(oracle.sqlToDataFrame(self.query_relatorio_motoristas))
        input("Pressione Enter para Sair do Relatório de Motoristas")