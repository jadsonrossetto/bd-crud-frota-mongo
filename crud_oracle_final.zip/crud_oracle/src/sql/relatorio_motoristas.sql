select m.codMotorista
      ,m.cpf
      , m.nome
  from motoristas m
 order by m.cpf