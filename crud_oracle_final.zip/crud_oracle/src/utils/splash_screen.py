from conexion.oracle_queries import OracleQueries
from utils import config

class SplashScreen:

    def __init__(self):
        # Consultas de contagem de registros - inicio
        self.qry_total_filiais = config.QUERY_COUNT.format(tabela="filiais")
        self.qry_total_veiculos = config.QUERY_COUNT.format(tabela="veiculos")
        self.qry_total_motoristas = config.QUERY_COUNT.format(tabela="motoristas")
        # Consultas de contagem de registros - fim

        # Nome(s) do(s) criador(es)
        self.created_by = "Jadson Rossêtto, " \
                          "Rafael Porto, " \
                          "Renato Torquato "
        self.professor = "Prof. M.Sc. Howard Roatti"
        self.disciplina = "Banco de Dados"
        self.semestre = "2022/2"

    def get_total_filiais(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Retorna o total de registros computado pela query
        return oracle.sqlToDataFrame(self.qry_total_filiais)["total_filiais"].values[0]

    def get_total_veiculos(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Retorna o total de registros computado pela query
        return oracle.sqlToDataFrame(self.qry_total_veiculos)["total_veiculos"].values[0]

    def get_total_motoristas(self):
        # Cria uma nova conexão com o banco que permite alteração
        oracle = OracleQueries()
        oracle.connect()
        # Retorna o total de registros computado pela query
        return oracle.sqlToDataFrame(self.qry_total_motoristas)["total_motoristas"].values[0]


    def get_updated_screen(self):
        return f"""
        ########################################################
        #                   SISTEMA DE VENDAS                     
        #                                                         
        #  TOTAL DE REGISTROS:                                    
        #      1 - FILIAIS:        {str(self.get_total_filiais()).rjust(5)}
        #      2 - VEICULOS:       {str(self.get_total_veiculos()).rjust(5)}
        #      3 - MOTORISTAS:     {str(self.get_total_motoristas()).rjust(5)}
        #
        #  CRIADO POR: {self.created_by}
        #
        #  PROFESSOR:  {self.professor}
        #
        #  DISCIPLINA: {self.disciplina}
        #              {self.semestre}
        ########################################################
        """